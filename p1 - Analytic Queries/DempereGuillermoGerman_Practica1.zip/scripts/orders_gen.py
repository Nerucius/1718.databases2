#! /usr/bin/python
import math, random

for i in range(1000):
    print "%d;Order no. %d" % (i+1, i+1)